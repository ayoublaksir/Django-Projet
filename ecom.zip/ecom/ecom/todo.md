- part 1

- create virtual envirpnement and activate it
- install django and create project
- create app for core views and add to installed apps
- add a single front page
- add static files

- create app for vendors and add to installed apps
- create database model for the vendors
- create view, template and form for sign up
- create simple area for vendors

- make it possible to log out and in again

- create app and models for products and categories
- show list of products in the admin area
- make it possibe for vendors to add products

- show newest products on the frontpage
- show detail view of a product
- show a category

- part 2

- make it possible to add product to cart
- create views and tamplate for cart
- make it possible to remove product from the cart
- make it possible to update the quantity

- create new app and models for the orders
- make it possible to checkout
- create a succes page

- show orders in the vendor area
- make it possible to edit a vendor
- notify the vendor after a sale

- show a list of vendors
- make it possible to see all products from a vendor

- part 3
