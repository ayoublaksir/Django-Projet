from product.views import product
from product.models import Product
from django.shortcuts import render
from vendor.models import Vendor, Client
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage

# Create your views here.


def administrator(request):
    number_of_vendors = Vendor.objects.all().count()
    number_of_clients = Client.objects.all().count()
    # number_of_orders = Order.objects.all().count()
    number_of_male_clients = Client.objects.filter(
        gender__gender="male").count()
    number_of_female_clients = Client.objects.filter(
        gender__gender="female").count()
    number_of_male_vendors = Vendor.objects.filter(
        gender__gender="male").count()
    number_of_female_vendors = Vendor.objects.filter(
        gender__gender="female").count()
    context = {"vendors": number_of_vendors, "clients": number_of_clients,
               "male_clients": number_of_male_clients,
               "male_vendors": number_of_male_vendors, "female_clients": number_of_female_clients, "female_vendors": number_of_female_vendors}
    return render(request, 'administrator/administrator.html', context)


def validation(request):

    products = Product.objects.filter(state='pending')
    if request.method == 'POST':
        product_id = request.POST.get('product_id', )
        product = Product.objects.get(id=product_id)
        if request.POST.get('accept'):
            product.state = "accepted"
            product.save()
        elif request.POST.get('refuse'):
            product.state = "refused"
            product.save()
    paginator = Paginator(products, 1)  # six items in page
    page = request.GET.get('page')
    try:
        products = paginator.page(page)
    except PageNotAnInteger:
        # if page not an integer deliver the first page
        products = paginator.page(1)
    except EmptyPage:
        # if page is out of range deliver the last page
        products = paginator.page(paginator.num_pages)

    context = {'products': products, 'paginate': True}
    return render(request, 'administrator/product_validation.html', context)


# "male_clients": number_of_male_clients,
    # "male_vendors": number_of_male_vendors, "female_clients": number_of_female_clients, "female_vendors": number_of_female_vendors}
