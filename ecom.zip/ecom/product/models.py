from django.db import models
from io import BytesIO
# pillow est une libr pour traitement , l'archivage , et l'affichage d'image
from PIL import Image
from django.core.files import File  # pour la representation des fichiers
from vendor.models import Vendor

# Create your models here.


class Category(models.Model):
    title = models.CharField(max_length=255)
    slug = models.SlugField(max_length=255)
    ordering = models.IntegerField(default=0)

    class Meta:
        ordering = ['ordering']

    def __str__(self):
        return self.title


class Product(models.Model):
    category = models.ForeignKey(
        Category, related_name='products', on_delete=models.CASCADE)
    vendor = models.ForeignKey(
        Vendor, related_name='product', on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    slug = models.SlugField(max_length=255)
    description = models.TextField(blank=True, null=True)
    price = models.DecimalField(max_digits=6, decimal_places=2)
    date_added = models.DateTimeField(auto_now_add=True)
    image = models.ImageField(upload_to='uploads/', blank=True, null=True)
    state_choices = [("accepted", "accepted"), ("refused",
                                                "refused"), ("pending", "pending")]
    state = models.CharField(max_length=9,
                             choices=state_choices,
                             default="pending")

    def __str__(self):
        return self.title


class Meta:
    ordering = ['-date_added']
