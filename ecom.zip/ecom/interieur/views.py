from django.core import paginator
from django.shortcuts import render
from product.models import Product, Category
from django.db.models import Q
# paginator pour avoir diviser le contenu en pls pages
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
import random


# Create your views here.
def home(request):
    products = Product.objects.filter(state='accepted')
    if len(list(products)) >= 4:
        news_products = random.sample(list(products), 4)
    else:
        news_products = products

    all_category = Category.objects.all()
    context = {'news_products': news_products,
               'all_category': all_category}

    return render(request, 'interieur/home.html', context)


def search(request):
    query = request.GET['query']
    category_name = request.GET['category_name']
    products_list = Product.objects.filter(
        (Q(title__icontains=query) | (Q(description__icontains=query))), category__title__icontains=category_name)
    paginator = Paginator(products_list, 6)  # six items in page
    page = request.GET.get('page')
    try:
        products = paginator.page(page)
    except PageNotAnInteger:
        # if page not an integer deliver the first page
        products = paginator.page(1)
    except EmptyPage:
        # if page is out of range deliver the last page
        products = paginator.page(paginator.num_pages)
    context = {'query': query, 'products': products, 'paginate': True}
    return render(request, 'product/search.html', context)


def all_products(request):
    all_products = Product.objects.all()
    context = {
        'all_products': all_products
    }
    return render(request, 'interieur/all_products.html', context)
