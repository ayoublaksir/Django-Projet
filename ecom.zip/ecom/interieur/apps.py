from django.apps import AppConfig


class InterieurConfig(AppConfig):
    name = 'interieur'
